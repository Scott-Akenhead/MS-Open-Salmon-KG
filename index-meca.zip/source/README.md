## Experimenting and Learning to use a Quarto Manuscript Template

Please ignore my fumblings at starting to start a project and a Quarto manuscript -- until this title and content changes to be more interesting (possibly).  
see: [Quarto Manuscripts: RStudio](https://quarto.org/docs/manuscripts/authoring/rstudio.html)  
Currently fighting Git+GitHub to pubish a test MS as a github web page: https://scott-akenhead.github.io/MS-Open-Salmon-KG/  
but from _manuscript/index.html not from README.md. 